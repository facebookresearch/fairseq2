---
name: model-port-planner
description: Create structured, phase-based implementation plans for porting models between frameworks (e.g., HuggingFace to fairseq2, PyTorch to JAX). Automatically sets up tmp-docs directory with plan files, component analysis, parity testing strategy, and commit workflow. Use when porting any ML model architecture between training frameworks or when planning large-scale model migrations.
---

# Model Port Planner

## Overview

Create comprehensive implementation plans for porting ML models between frameworks. Automatically generates phase-based plans in `tmp-docs/` directory with architecture analysis, component mapping, parity testing strategy, and git workflow.

## When to Use

Trigger this skill when:
- Porting models between frameworks (HuggingFace ↔ fairseq2, PyTorch ↔ JAX, etc.)
- User says "port [model] to [framework]"
- User asks to "plan implementation of [model]"
- Any model architecture migration requiring >3 days work

## Workflow

### Step 1: Gather Requirements

Ask clarifying questions:
- **Source framework**: Where is the reference implementation? (HuggingFace, GitHub repo, paper-only)
- **Target framework**: Where to implement? (fairseq2, custom framework)
- **Model variant**: Which size/configuration? (smallest recommended for iteration speed)
- **Precision targets**: fp32, bf16, or both?
- **Scope**: Full architecture or minimal viable port?
- **Parity testing**: What reference outputs to match? (inference, training, both)

### Step 2: Explore Architectures

Use existing tools to gather context:
- **Explore agent**: Understand target framework patterns (model structure, testing, recipes)
- **Read source**: Analyze reference implementation (modeling file, config, key components)
- **Identify primitives**: What can be reused vs what needs new implementation

### Step 3: Create tmp-docs Structure

Automatically create planning directory:

```
tmp-docs/
├── CLAUDE.md              # Project tracker with progress checkboxes
├── plan-overview.md       # High-level summary (goal, strategy, timeline)
└── plan-phase-N.md        # Detailed phase plans (5-7 files, <300 lines each)
```

Also save any reference documentation (architecture specs, paper summaries, component lists).

### Step 4: Design Phase Breakdown

Create 5-7 implementation phases, each 1-3 days:

**Standard phase structure for model ports:**
1. **Module structure & config** - Directory setup, config dataclass, component mapping
2. **Core components** - Position encodings, attention, FFN, layer implementations
3. **Inference parity** - Test infrastructure, component tests, full model tests (fp32/bf16)
4. **Training integration** - Recipe setup, dataset, training parity tests
5. **Advanced features** - Optimizations, distributed training, special architectural features

**Each phase plan includes:**
- Component specifications with code examples
- Verification tests for each component
- Commit strategy (what, LOC estimate, test requirements)
- Deliverables checklist
- Quality checkpoints (`/unslop-code`, `/better-engineering`)

### Step 5: Write Plan Files

**plan-overview.md** (~150-200 lines):
- Goal and scope
- Strategy (decisions, constraints, approach)
- Git workflow guidelines (<1k LOC commits, test requirements)
- Phase summaries with deliverables
- Total timeline and LOC estimates
- Critical files to modify/create
- References and resources

**plan-phase-N.md** (each <300 lines):
- Detailed component specs
- Implementation examples
- Commit breakdown for phase
- Verification strategy
- Next phase pointer

**CLAUDE.md** (project tracker):
- Current status and phase
- Key architecture findings
- Progress checkboxes for each deliverable
- Open questions and blockers

### Step 6: Include Parity Testing Strategy

**Critical for model ports:** Plans must specify how to verify correctness.

For each phase, include:
- What to compare against reference implementation
- Tolerance levels for numerical differences (fp32: 1e-4, bf16: 1e-2)
- Layer-by-layer debugging approach
- Test infrastructure setup

**Parity testing is a key deliverable** - not optional for model ports.

### Step 7: Add Git Workflow Guidelines

Every plan must include:
- Commit message format: `[project] Brief description`
- LOC limits: <1k per commit where possible
- Test requirements: Every commit includes tests
- Quality gates: `/unslop-code` and `/better-engineering` after each phase

Example commit strategy:
```
Phase 2 commits:
1. [project] Add PositionEncoder implementation (~200 LOC + tests)
2. [project] Add Attention wrapper (~150 LOC + tests)
3. [project] Add FFN implementation (~200 LOC + tests)
4. [project] Phase 2 code quality cleanup
```

## Output Structure

After running this skill, user will have:
- ✅ Complete implementation plan in `tmp-docs/`
- ✅ Phase-by-phase breakdown with commit strategy
- ✅ Parity testing approach
- ✅ Progress tracking with checkboxes
- ✅ Ready to begin Phase 1 implementation

## Example Usage

**User**: "Port Gemma3n from HuggingFace to fairseq2"

**Skill workflow**:
1. Ask: model size? (2B) precision? (fp32+bf16) scope? (full architecture)
2. Explore fairseq2 patterns and HuggingFace Gemma3n implementation
3. Create tmp-docs/ with 7 files (overview + 5 phase plans + tracker)
4. Design 5 phases: structure, components, parity, training, advanced features
5. Include parity strategy: compare logits fp32 (1e-4), bf16 (1e-2)
6. Specify git workflow: <1k LOC commits, tests required

**Result**: User has complete roadmap to implement Gemma3n in fairseq2.

## Notes

- Keep phase plans <300 lines to avoid output truncation
- Always include LOC estimates for commits
- Parity testing is non-negotiable for model ports
- Reference `/home/aerben/CLAUDE.md` for planning template structure
